# stocksCrawler
Project designed to retrieve historcial data from Yahoo Finance stocks. The crawler reads the most active stocks and load it on a local PostgreSQL table.

Prject Requirements:
python3.10
scrapy
pandas
pandas 
json
psycopg2
sqlalchemy

#start the crawler
#run scrapy crawl yahooStocks on ./Crawler folder
